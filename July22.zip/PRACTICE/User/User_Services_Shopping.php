<?php 
session_start();
include 'User_Function.php';
if(isset($_POST["AddToCart"]) && isset($_SESSION["is_UserLogin"]))
{
 $_SESSION["P_ID"]=$_POST["Product_id"];
}

include('../Includes/dbconn.php');  

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
   <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.css">
    <script src="../CSS/all.min.js"></script>
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>

    <!-- Google Font -->
 <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">

     <style>
         img{
          width:80%;
           height:200px;
           margin:auto;
         }
     </style>
    
   
</head>
<body>
 
<!--Heading start-->
<div class=" navbar Containers text-white bg-success sticky ">
<a href="" class="navbar-brand text-white ml-2"><h1>Code Solution</h1></a>
<a href="cart.php" class="navbar-brand nav-link text-white ml-2">
  <h1><i class="fas fa-shopping-cart"></i>
  

</h1></a>
  </div><!--Heading End-->

  <!--Options for service-->
  <div class=" navbar  bg-light " style="height=50px;">
   <a href="UserServices.php" class="nav-link btn btn-primary">Order Request</a>
  <a href="User_Services_Shopping.php" class="nav-link btn btn-primary active">Shopping</a>

  </div>
  <div class="container-fluid mt-2">
  <div class="row">
    <?php include('../Includes/Header.php');?><!--Adding Sidebar-->

<!--Start item Viewer-->

<div class="container-fluid">
    <div class="row px-5">
        <div class="col-md-7 ">
      <?php
      $result=getdata();
       while($row=mysqli_fetch_assoc($result))
       {
         echo "<form action=\"User_Services_Shopping.php\" method=\"post\"></form>
         <div class=\"border rounded\">
             <div class=\"row bg-white\">
                 <div class=\"col-md-3\">
                <img  class=\"image\" src='../Admin/{$row['product_pic']}  '>
                 </div>
                <div class=\"col-md-6\">
               <h5 class=\"card-title\">{$row["product_name"]}</h5>
               <h6>
                <i class=\"fas fa-star\"></i>
                <i class=\"fas fa-star\"></i>
                <i class=\"fas fa-star\"></i>
                <i class=\"fas fa-star\"></i>
               </h6>
               <p class=\"card-text\">{$row["product_description"]}</p>
               <h5>
              <small><s>799</s></small>
               <span class=\"price\">{$row["product_price"]}</span>
               </h5>
               <input type=\"hidden\" name=\"Product_id\" value='{$row["product_id"]}'>";

        if (Check_Item_In_Cart($row['product_id'],$_SESSION['U_ID'])) {   
          echo "<a href='Cart_Item_Add.php?id={$row['product_id']}' class='btn btn-block btn-success' disabled>Added to cart</a>";
          }
           else {
          echo "<a href='Cart_Item_Add.php?id={$row['product_id']}' name=\"AddToCart\" value=\"AddToCart\" class='btn btn-block
         btn-primary'>Add to Cart <i class=\"fas fa-shopping-cart\"></i></a>";
           }
           echo"</div></div></form></div>";
          }
        
        


      ?> 
     
      </div>
    </div>
   </div>