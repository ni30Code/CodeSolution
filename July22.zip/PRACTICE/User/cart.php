<?php 
session_start();
include '../Includes/dbconn.php';
$user_id= $_SESSION['U_ID'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
   <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.css">
    <script src="../CSS/all.min.js"></script>
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>

    <!-- Google Font -->
 <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">

     <style>
         img{
          width:80%;
           height:200px;
           margin:auto;
         }
     </style>
    
   
</head>
<body>
 
<!--Heading start-->
<div class=" navbar Containers text-white bg-success sticky ">
<a href="" class="navbar-brand text-white ml-2"><h1>Code Solution</h1></a>

  </div><!--Heading End-->
  <div class="container-fluid mt-2">
  <div class="row">
    <?php include('../Includes/Header.php');?><!--Adding Sidebar-->

    <div class="container-fluid">
    <div class="row px-5">
        <div class="col-md-7 ">
        <div class="shopping-cart">
              
                <form action="" method="post"></form>
<?php
  include 'User_Function.php';
 if(isset( $_SESSION['P_ID']))
{
   $result=getCart( $_SESSION['P_ID']);
   while($row=mysqli_fetch_assoc($result)){
   GetCartItems($row["product_pic"],$row["product_category"],$row["product_name"],$row["product_price"],$row["product_description"]);
  }
}

?>

<div class="container">  
 
<table id="mytable" class="display border"  style="width:100%" border="2px">
  <thead>
    <tr>
      <th scope="col">Item no</th>
      <th scope="col">Item Name</th>
      <th scope="col">price</th>
      <th scope="col"></th>
      <th scope="col">Image</th>
    </tr>
  </thead>
  <tbody class="border">
  <?php
  include 'Check-if-ordered.php';
  $sql = "SELECT user_items.id AS MY_PROJECTS_ID, tb_product.product_id,tb_product.product_pic, tb_product.product_name ,tb_product.product_description,tb_product.product_price FROM tb_product INNER JOIN user_items ON user_items.item_id =tb_product.product_id where user_items.user_id= $user_id ; ";
  $result = $conn->query($sql);
  
if ($result->num_rows > 0) {
  // output data of each row
  
  
  while($row = $result->fetch_assoc()) {
    $_SESSION["Product_ID"]=$row["product_id"];
    $_SESSION["Product_Name"]=$row["product_name"];
    $_SESSION["Product_Price"]= $row["product_price"];
    //$sum =" "+$row['price'];
    
    echo "<tr><td>id: " . $row["product_id"]."</td>  - <td>Name: " . $row["product_name"]. "</td> <td>price : " . $row["product_price"]. "</td><td><a href='cart-remove.php?id={$row['MY_PROJECTS_ID']}'   class='btn btn-primary'> Remove</a>";
     
      if (check_if_ordered($row['MY_PROJECTS_ID'])) { //This is same as if(check_if_added_to_cart !=
    //0)
    $temp="../".$row["product_pic"];
      echo "<a  class='btn btn-success mt-2 disabled'  href='#'  >Confirmed </a></td><td>
      <img src=\"$temp\"></img></td> </tr> </br>";
  
     }
      else {
        $temp="../".$row["product_pic"];
      echo  "<a href='success.php?id={$row['product_id']}' class='btn btn-primary mt-2'>Confirm Order</a></td><td>
      <img  src=\"$temp\"></img></td> </tr></br>";
     
     }
     }
     
   // echo "<a href='success.php?id={$row['id']}' class='btn btn-primary'> corfirm order</a></td> </tr></br>";
    

  }
 // echo $sum;
 // echo $id;
  //echo "";

else{
  echo "<tr><td><h1>Add items to the cart first!<h1></td></tr>";
}
$conn->close();
 ?>
   
    
      
  </tbody>
</table>
<a href="../Invoice.php" class="btn btn-primary nav-link m-4">Get Invoice</a>

                
</body>
</html>


