<?php
 session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>product page</title>
 
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.css">
    <script src="../CSS/all.min.js"></script>
    
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>
    
     <!-- Custom CSS -->
    <link rel="stylesheet" href="../CSS/custom.css">
   
<style type="text/css">
  h3
  {
    margin-top: 70px;
  }
</style>
</head>

<body>
  <!-- Navbar Start Here-->
  <nav class="navbar navbar-expand-sm navbar-dark bg-success pl-5 ">
        <a href="#" class="navbar-brand ml-2">Code Solutions</a>
    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#Mymenu">
        <span class="navbar-toggler-icon">
        </span>
    </button>
     <div class="collapse navbar-collapse ml-5" id="Mymenu">
        <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="User_Services_Shopping.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="UserServices.php">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="../Includes/Logout.php"><i class="fas fa-power-off"></i>Logout</a></li>
     </ul>
     </div>
    </nav> <!-- Navbar End Here-->
	<body>
  <div class="container"> 
  
   <?php 
  include '../Includes/dbconn.php';
$item_id=$_GET['id'];
$user_id=$_SESSION['U_ID'];

$sql = "UPDATE user_items SET status='confirmed' WHERE item_id = $item_id and user_id = $user_id ;";

if ($conn->query($sql) === TRUE) {
 // echo "<h2>Record updated successfully</h2>";

  echo "<h3> Your order is confirmed. Thank you for shopping
with us. <a href='User_Services_Shopping.php'>Click here</a> to purchase any other item.
</h3>";
}
 else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();



   ?>
 
 
 
<!-- row  2 end -->
<!-- row  3 start -->

 
  


</div>
</body>
</html>
