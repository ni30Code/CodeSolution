<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.min.css">
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>
     
     <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">
   
</head>
<body>
<!--Heading start-->
<div class="Containers text-white bg-success sticky">
<a href="" class="navbar-brand text-white ml-2">Code Solution</a>
  </div><!--Heading End-->


 <div class="container-fluid">
  <div class="row">
    <?php include('../Includes/Header.php');?><!--Adding Sidebar-->
   <div class="cols-sm-4 pl-5 mt-4" >
      <form action="#" method="post" class="form-group">
      <input type="text" Placeholder="Enter Status No" class="form-control">
      <input type="button" value="Get Status"  class="btn btn-primary mt-2">
      </form>
   </div>
  </div>
 </div>
