
<?php
session_start();
include('../Includes/dbconn.php');

 if($_SESSION['is_UserLogin']){
  $Email = $_SESSION["Email"];
 } else {
  echo "<script> location.href='Login.php'</script>";
 }
 $sql = "SELECT * FROM tb_usertable WHERE U_email = '$Email'";
 $result = $conn->query($sql);
 if($result->num_rows == 1){
  $row = $result->fetch_assoc();
  $uName = $row['U_name'];
  $uContact=$row['U_Contact'];
  $_SESSION["U_ID"]=$row['U_ID'];
 
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.css">
    <script src="../CSS/all.min.js"></script>
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>

    <!-- Google Font -->
 <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">
   
</head>
<body>
<div class="containers text-white my-1">
<nav class=" navbar navbar-expand bg-success">
<a href="" class="navbar-brand text-white">Code Solution</a>

<ul class="navbar-nav ml-auto">
<li class="nav-link"><strong><i class="fas fa-user"></i><?php if($result->num_rows>0){echo "Welcome:".$uName;} ?></strong></li>
</ul>
</nav>

</div>







<div class="container-fluid mt-4">
<div class="row">
<?php 
include('../Includes/Header.php');
?>
<div class="cols-sm-4 pl-5" >
<form action="#" method="post" class="form-group">
<input type="Email" Placeholder="Your mail" class="form-control" value="<?php echo $_SESSION["Email"]; ?>" readonly><br>
<input type="text" placeholder="Your name" value="<?php echo $uName; ?>" class="form-control"><br>
<input type="text" value=" <?php echo  $uContact; ?>" placeholder="Enter your number" class="form-control"><br>
</form>

</div>
</div>
</div>



</div>