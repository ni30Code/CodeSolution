<?php
session_start();
include 'includes/Common.php';
 include '../Includes/dbconn.php';


 $user_id=$_SESSION['U_ID'];
 $item_id=$_GET['id'];

 
 
$sql = "INSERT INTO user_items(user_id, item_id, status) VALUES('$user_id', '$item_id', 'Added to cart')";

if ($conn->query($sql) === TRUE) {
  echo "New record Created Cuccessfully";
  header("Location:User_Services_Shopping.php");
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

 

$conn->close();

 

?>
