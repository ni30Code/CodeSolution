<?php


function  check_if_ordered($item_id)
{
  include '../Includes/dbconn.php';
$user_id=$_SESSION['U_ID'];
$sql = "SELECT * FROM user_items WHERE id='$item_id' AND status='confirmed' AND user_id = '$user_id' ; ";
$result = $conn->query($sql);

if ($result->num_rows >= 1) {
  // output data of each row
  return 1;
} else {
  return 0;
}


}

?>