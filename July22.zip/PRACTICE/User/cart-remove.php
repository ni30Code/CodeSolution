<?php
session_start();
include '../includes/dbconn.php';
$user_id=$_SESSION['U_ID'];
$id=$_GET['id'];  
// sql to delete a record
$sql = "DELETE FROM user_items WHERE user_id= $user_id  and  id= $id ";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
  header("Location:cart.php");
} else {

    echo "Error deleting record: " . $conn->error;
}

$conn->close();



?>