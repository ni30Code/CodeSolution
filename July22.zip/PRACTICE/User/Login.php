<?php
 session_start();
if(isset($_SESSION["is_UserLogin"]))
{
   header('location:UserProfile.php');
}
include('../Includes/dbconn.php');
if(!isset($_SESSION['is_UserLogin'])){
   if(isset($_REQUEST['Email'])){
    $Email = mysqli_real_escape_string($conn, trim($_REQUEST['Email']));
    $Password = mysqli_real_escape_string($conn, trim($_REQUEST['Password']));
    echo $Email;
    echo $Password;
    $sql = "SELECT * FROM `tb_usertable` WHERE `U_Email`= '$Email' AND `U_Password` = '$Password' limit 1";
    $result = $conn->query($sql);
    if($result->num_rows == 1){
     $_SESSION['is_UserLogin'] = true;
     $_SESSION['Email'] = $Email;
     
     echo "<script> location.href='UserProfile.php';</script>";
     exit;
    } else {
     $errMessage = '<div class="alert alert-warning mt-2">Enter Valid Email and Password</div>';
    }
   }
  } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login:Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.min.css">
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>

    <!-- Google Font -->
 <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">
   
</head>
<body>
<div class="container-fluid ">
<h1 class="text-center">Welcome to Code Solution</h1>
<div class="row justify-content-center">
<div class="col-sm-4">
<form action="Login.php"  class="shadow-lg p-4"  method="post">
<label for="" class="font-weight-bold pl-2 mt-3">Email</label>
<input type="Email" name="Email" id="Email" class="form-control">
<small class="form-text">We Will never share this Email</small>
<label for="" class="font-weight-bold pl-2 mt-3">Password</label>
<input type="Password" name="Password" id="Password" class="form-control">
<input type="submit" name="Login" value="Login" class="form-control btn-success mt-3">
</form>
<?php if(isset($errMessage)) {echo $errMessage;} ?>
<div class="text-center">
<a href="../index.php" class="btn btn-primary text-center mt-2">Back To Home</a>
</div>

</div>
</div>


</body>
</html>