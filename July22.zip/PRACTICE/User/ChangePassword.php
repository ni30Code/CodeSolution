
<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Change Password</title>

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../CSS/bootstrap.min.css">

  <!-- Font Awesome CSS -->
  <link rel="stylesheet" href="../CSS/all.css">
  <script src="../CSS/all.min.js"></script>
   <!-- JavaScript -->
   <script src="../JS/jquery.min.js"></script>
   <script src="../JS/popper.min.js"></script>
   <script src="../JS/bootstrap.min.js"></script>
  
  <!-- Custom CSS -->
 <link rel="stylesheet" href="CSS/custom.css">
 
</head>

<body class="bg-gradient-primary">
<div class="Containers text-white bg-success sticky">
<a href="" class="navbar-brand text-white ml-2">Code Solution</a>
  </div><!--Heading End-->
  <?php include '../Includes/header.php' ?>
    <form action="ChangePassword.php" class="container" style="width:30%; height=20%;">
        <label for="form-group">Old Password</label>
         <input type="password" class="form-control" name="old_pwd">
        <label for="form-group" >New Password</label>
         <input type="password" class="form-control" name="new_pwd">
        <label for="form-group" >Confirm Password</label>
         <input type="password" class="form-control" name="c_new_pwd">
        <input type="submit" class="btn btn-primary mt-2" value="Change">
    </form>