<?php

include('../Includes/dbconn.php');  
function component($product_name,$product_price,$product_desc,$product_image,$product_id)
 {
     $element="
     <div class=\"cols-sm-6 cols-md-3 m-1\">
     <form action=\"User_Services_Shopping.php\" method=\"post\">
     <div class=\"card shadow\" \">
     <div class=\"containers \">
     <img  class=\"image\" src=\"../$product_image\"  \">
     </div>
     <div class=\"card-body\">
     <h5 class=\"card-title\">$product_name</h5>
     <h6>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
    </h6>
    <p class=\"card-text\">$product_desc</p>
    <h5>
      <small><s>799</s></small>
      <span class=\"price\">$product_price</span>
    </h5>
    <input type=\"hidden\" name=\"Product_id\" value=\"$product_id\">
    <button type=\"submit\" class=\"btn  bg-warning\" name=\"AddToCart\">Add to Cart <i class=\"fas fa-shopping-cart\"></i></button>
   </div>
 </div>
 </form>
 </div>";
 echo $element;
 }


 function getCart($id)
 {
  include ('../Includes/dbconn.php');
  $sql="SELECT * FROM tb_product WHERE $id ";
  $run=mysqli_query($conn,$sql);
  if(mysqli_num_rows($run)>0)
     return $run;
 }


 function getdata()
 {
  include ('../Includes/dbconn.php');
  $sql="SELECT * FROM tb_product";
  $run=mysqli_query($conn,$sql);
  if(mysqli_num_rows($run)>0)
     return $run;
 }


 function GetCartItems($product_image,$product_category,$product_name,$product_price,$product_desc)
 {
   $element="<div class=\"container-fluid\">
   
                <div class=\"border rounded\">
                    <div class=\"row bg-white\">
                        <div class=\"col-md-3\">
                            <img src=\"../$product_image\"  class=\"img-fluid\">
                        </div>
                        <div class=\"col-md-6\">
                           <h5 class=\"pt-2\">$product_name</h5>
                           <small class=\"text-secondary\">:Category$product_category</small>
                           <h5 class=\"pt-2\">$product_price</h5>
                           <p class=\"card-text\">$product_desc</p>

                           <button type=\"submit\" class=\"btn btn-warning\">Save for Later</button>
                           <button type=\"submit\" class=\"btn btn-danger\">Remove</button>
                        </div>
                        <div class=\"col-md-3 py-5\">
                        <button class=\"btn btn-light border rouned-cirle\"><i class=\"fas fa-minus\"></i></button>
                        <input value=\"1\" class=\"form-control w-25 d-inline\"></form>
                        <button class=\"btn btn-light border rouned-cirle\"><i class=\"fas fa-plus\"></i></button>  
                          
                          
 \
                        </div>
                    </div>
                </div>
           </div>
       ";
 echo $element;
  
 }



 function Check_Item_In_Cart($P_ID,$user_id)
{
	//Including Database Connection
	 include '../Includes/dbconn.php';

$user_id;
$sql = "SELECT * FROM user_items WHERE item_id='$P_ID' AND user_id ='$user_id' and status='Added to cart' ";
$result = $conn->query($sql);

if ($result->num_rows >= 1) {
  // output data of each row
  return 1;
} else {
  return 0;
}
}
 ?>