<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.min.css">
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>

    <!-- Google Font -->
 <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">
   
</head>
<body>
    <!--Heading start-->
    <div class="containers text-white bg-success sticky ">
      <a href="" class="navbar-brand text-white ml-2">Code Solution</a>
    </div><!--Heading End-->

    <!--Options for service-->
    <div class=" navbar  bg-light " style="height=50px;">
     <a href="UserServices.php" class="nav-link btn btn-primary active">Order Request</a>
     <a href="User_Services_Shopping.php" class="nav-link btn btn-primary">Shopping</a>
    </div> <!-- End--Options for service-->

  
<div class="row "><!--Form and Navigation  Section  Start Here-->
<!--First Column Start Here-->
    <?php include('../Includes/Header.php');?><!--Adding Sidebar-->
<!--First Column End Here-->

<div class="col-md-9 cols-sm-8 mt-2 justify-content-center "><!-- Second Column Start Here-->
<form action="InsertProduct.php" method="post" enctype="multipart/form-data" class="shadow-lg p-4 form-group">
      <h1 class="text-center">Service Request Form</h1><hr>
      <div class="row m-2 justify-content-center">
       <div class="cols-md-6 p-4"><!--Colum1 start Here-->
       <label for="Name">Name</label> 
         <input type="Email" name=""  id="Name" Placeholder="Your mail" class="form-control" >
         <label for="Email">Email</label>
         <input type="Email" name="" id="Email" Placeholder="Your mail" class="form-control" >
         <label for="Contact">Contact</label>
         <input type="text" name="" id="Contact" value="" placeholder="Enter your number" class="form-control">
        </div><!--Colum1 End Here-->

      <div class="col-md-6"><!--Colum2start Here-->
           <label for="Choice" class="mt-4">What you want:</label>
              <select name="Choice" id="" class="form-control">
                <option value="Web Development">Android Development</option>
                <option value="Android Development">Web Development</option>
                <option value="Android Development">Desktop Application</option>
              </select>
            <label for="Choice" >Services Type:</label>
              <select name="Choice" id="" class="form-control">
                <option value="Project Development">Project Development</option>
                <option value="Maintainence">Maintaience</option>
                <option value="Troubleshooting">Troubleshooting</option>
              </select>
        </div><!--Colum2 End Here-->
        </div><!--Row End Here-->
       

           <label for="Choice"  class=" form-group mt-2" >Description:</label>
               <textarea name="" id="" cols="30" rows="10" class="form-control"></textarea><br>
               <input type="button" value="Submit"  class="form-control btn-primary">
      
      </div>
      </form>

