<?php
session_start();
//Function for  reply to contacted  person
include 'Includes/dbconn.php';
  function ContactReply($Contactername,$Contacteremail){
   $msg="Thankyou ".$Contactername." For Contacting Us";
   echo $msg;
   echo $Contacteremail;
   $sub="This is for Verification";
   mail($email,$sub,$msg);
  }
  if(isset($_POST["Send"]))
 {
   //If form Element is blank
   if(($_POST['Name'] == "") ||($_POST['Email'] == "")||($_POST['Subject'] == "")||($_POST['Message'] == "")){
    $errMessage ='<div class="alert alert-warning mt-2" role="alert">All Fields are Required</div>';
    } 
    else{
      $name=$_POST['Name'];
      $email=$_POST['Email'];
      $subject=$_POST['Subject'];
      $message=$_POST['Message'];
      
    $q="INSERT INTO `contactus`( `Name`, `Email`, `Subject`, `Feedback`) VALUES ('$name','$email','$subject','$message')";
    $sql=mysqli_query($conn,$q);
      if($sql){
       $errMessage = '<div class="alert alert-warning mt-2" role="alert">Thank You For Contatcting Us</div>';
       ContactReply($name,$email);
       echo "Done";
      header('location:index.php');
       }
     
      }
    }
  
  






 
  ?>
 