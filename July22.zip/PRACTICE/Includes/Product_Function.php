<?php
//Function For Displaying Data Dynamically When User Is  Logged In
function Logincomponent($product_name,$product_price,$product_desc,$product_image,$product_id)
 {

     $element="
     <div class=\"cols-sm-6 cols-md-3 m-1\">
     <form action=\"User_Services_Shopping.php\" method=\"post\">
     <div class=\"card shadow\" \ style=\"height=300px; width=300px;\">
     <div class=\"containers \">
     <img  class=\"image\" src=\"Admin/$product_image\"  \">
     </div>
     <div class=\"card-body\">
     <h5 class=\"card-title\">$product_name</h5>
     <h6>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
    </h6>
    <p class=\"card-text\">$product_desc</p>
    <h5>
      <small><s>799</s></small>
      <span class=\"price\">$product_price</span>
    </h5>
    <input type=\"hidden\" name=\"Product_id\" value=\"$product_id\">
    <a href=\"User/Login.php\" class=\"btn  bg-warning\" name=\"AddToCart\">Add to Cart <i class=\"fas fa-shopping-cart\"></i></a>
   </div>
 </div>
 </form>
 </div>";
 echo $element;
 }
//Function For Displaying Data Dynamically When User Is  Logged Out
 Function WithoutLoginComponent($product_name,$product_price,$product_desc,$product_image,$product_id)
 {

     $element="
     <div class=\"col-sm-6 col-md-3 m-1\">
     <form action=\"User_Services_Shopping.php\" method=\"post\">
     <div class=\"card shadow\" \ style=\"height=300px; width=300px;\">
     <div class=\"containers \">
     <img  class=\"image\" src=\"Admin/$product_image\" >
     </div>
     <div class=\"card-body\">
     <h5 class=\"card-title\">$product_name</h5>
     <h6>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
       <i class=\"fas fa-star\"></i>
    </h6>
    <p class=\"card-text\">$product_desc</p>
    <h5>
      <small><s>799</s></small>
      <span class=\"price\">$product_price</span>
    </h5>
    <input type=\"hidden\" name=\"Product_id\" value=\"$product_id\">
    <button type=\"submit\" class=\"btn  bg-warning\" name=\"BuyNow\">Buy Now<i class=\"fas fa-shopping-cart\"></i></button>
   </div>
 </div>
 </form>
 </div>";
 echo $element;
 }



 function getdata()
 {
  include ('dbconn.php');
  $sql="SELECT * FROM tb_product";
  $run=mysqli_query($conn,$sql);
  if(mysqli_num_rows($run)>0)
     return $run;
 }
  function AddProduct($category,$name,$RAM,$price,$pic,$desc)
 {
  include ('dbconn.php');
  $sql="INSERT INTO `tb_product`(`product_category`, `product_name`, `RAM`,`product_price`, `product_pic`, `product_description`) 
  VALUES ('$category',' $name','$RAM','$price','$pic','$desc')";
  if($run=mysqli_query($conn,$sql))
  {
     return true;
  }
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<style>
  img{
      width:80%;
      height:200px;
      margin:auto;
         }
</style>
<body>
  
</body>
</html>