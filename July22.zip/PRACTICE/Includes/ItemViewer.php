<?php
session_start();
//Including Database Connection
 include('dbconn.php'); 
 //Including Function Written For Product Fetching 
 include 'Product_Function.php';  
        $result=getdata();
          while($row=mysqli_fetch_assoc($result)){
         //Function For Printing Product From Database Dynamically
         if(isset($_SESSION["is_UserLogin"])){
          Logincomponent($row["product_name"],$row["product_price"],$row["product_description"],$row["product_pic"],$row["product_id"]);
         }else{
          WithoutLoginComponent($row["product_name"],$row["product_price"],$row["product_description"],$row["product_pic"],$row["product_id"]);
         }
       
        }
?>
</body>
</html>