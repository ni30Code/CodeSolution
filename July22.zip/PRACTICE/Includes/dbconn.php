<?php
   $host="localhost";
   $user="id14436170_nitish";
   $pass="CKG_cm!BtU#1^+-V";
   $db="id14436170_codesolution";
   //Creating dtadbase connation
   $conn=mysqli_connect($host,$user,$pass,$db);
?>