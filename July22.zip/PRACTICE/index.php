<?php
session_start();
         
?>
<!DOCTYPE html"
<html lang="en">
<head>
</head>
<body>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Solutions</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="CSS/all.css">
    <script src="CSS/all.min.js"></script>
    
     <!-- JavaScript -->
     <script src="JS/jquery.min.js"></script>
     <script src="JS/popper.min.js"></script>
     <script src="JS/bootstrap.min.js"></script>
    
     <!-- Custom CSS -->
    <link rel="stylesheet" href="CSS/custom.css">
   
</head>
<body>
    <!-- Navbar Start Here-->

    <nav class="navbar navbar-expand-sm  navbar-dark bg-success pl-5 fixed-top">
        <a href="#" class="navbar-brand ml-2">Code Solutions</a>
    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#Mymenu">
        <span class="navbar-toggler-icon">
        </span>
    </button>
     <div class="collapse navbar-collapse ml-5" id="Mymenu">
        <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="#Home">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#Services">Services</a></li>
        <li class="nav-item"><a class="nav-link" href="#ContactUS">Contact Us</a></li>
        <li class="nav-item"><a class="nav-link" href="#AboutUS">About Us</a></li>
        <li class="nav-item"><a class="nav-link" href="User/Login.php"><i class=" fas fa-user ml-2 "></i> Login</a></li>
     </ul>
     </div>
    
    </nav> <!-- Navbar End Here-->
    

    <!--Start Website Heading-->

    <header id="Home" class="jumbotron bgimage" style="background-image:url(Images/BG_IMAGE1.jpg);background-size: cover; background-position: center center;
                                                                background-repeat: no-repeat;min-height: 100vh;border-radius: 0px;">
        <div class="Website_Heading">
          <h1 class="mt-5">Welocme to Code Solutions</h1>
            <a href="User/Login.php" class="btn btn-success">Login</a>
            <a href="Signup.php" class="btn btn-danger">Signup</a>
         </div>
    </header> <!--End Website Heading-->

    
<!--IStart item Viewer-->
    <div class="row container justify-content-center" id="Services">
      <div class="col-md-12">
      <h1 class="text-center m-2">Our Product</h1> <hr>
    <?php
    include('ItemViewer.php');
    ?>
       
      </div>
    
    </div>
    <!--End item Viewer-->
     <!--Start Website intro-->\
     <div class="container" id="AboutUS">
      <div class="jumbotron">
      <h1>Code Solutions</h1>
       <p>We are leading in Website world market  with our fully dedicated team.
       We provide software solutions with latest technolgy with cheapest price.
       We have 100 full stack web developer.
       In today world everyone want to be digitally active.So here we come with 
       our service to connect bussiness with digital web.
      </p>
      </div>
     </div><!--End Website intro-->

   <!--Start Service Section-->
   <div class="container text-center">
       <h2>Our Services</h2>
      <div class="row mt-4">
       <div class="col-sm-4 mb-4">
        <a href="#"><i class="fas fa-tv fa-8x text-success"></i></a>
         <h4 class="mt-4">Electronic Appliances</h4>
       </div>
      <div class="col-sm-4 mb-4">
       <a href="#"><i class="fas fa-sliders-h fa-8x text-primary"></i></a>
       <h4 class="mt-4">Preventive Maintenance</h4>
      </div>
      <div class="col-sm-4 mb-4">
        <a href="#"><i class="fas fa-cogs fa-8x text-info"></i></a>
        <h4 class="mt-4">Programming Tutorial</h4>
      </div>
     </div>
   </div><!--End Service Section-->


<!--Contact form  start here-->
   <div class="container text-center" id="ContactUS">
   <h1>Contact Us</h1>
     <div class="row shadow  bg-light"><!--Contact form  start here-->
     
<div class="col-sm-8 p-4"><!--Contact Form -->
       <form action="ContactUS.php" method="post">
         <input type="text" class="form-control" name="Name" value="" placeholder="Enter Name"><br>
         <input type="Email" class="form-control" name="Email" value="" placeholder="Email"><br>
         <input type="text" class="form-control" name="Subject" value="" placeholder="subject"><br>
         <label for="Message ">Messaage</label>
         <textarea name="Message" class="form-control" id="Message" cols="30" rows="10"></textarea><br>
         <input type="submit"  class="form-control btn-primary" name="Send" value="Send" >
       </form>
       <?php if(isset($errMessage)) {echo $errMessage;} 

       ?>
      </div><!--Contact form end-->


    <div class="col-sm-4 p-4">
       <strong>Headquarter</strong><br>
       454,Jeevan Nagar-2,Gaunchhi<br>
       12004,Faridabad<br>
       Haryana,India<br><br>
       <strong>Headquarter</strong><br>
       454,Jeevan Nagar-2,Gaunchhi<br>
       12004,Faridabad<br>
       Haryana,India
    </div>
   </div>
  </div><!--Contact form  end here-->


 
 <!-- Start Footer -->
 <footer class="container-fluid bg-dark mt-5 text-white">
  <div class="container">
   <div class="row py-3">
    <div class="col-md-6"> <!-- Start 1st Column -->
     <span class="pr-2">Follow Us: </span>
     <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-facebook-f"></i></a>
     <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-twitter"></i></a>
     <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-youtube"></i></a>
     <a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-google-plus-g"></i></a>
     <a href="#" target="_blank" class="pr-2 fi-color"><i class="fas fa-rss"></i></a>
    </div> <!-- End 1st Column -->
    <div class="col-md-6 text-right"> <!-- Start 2nd Column -->
     <small>Designed by Nitish &copy; 2020</small>
     <small class="ml-2"><a href="Admin/Login.php" class="text-primary">Admin Login</a></small>
    </div> <!-- End 2nd Column -->
   </div>
  </div>
 </footer>
   <!-- Footer End Here -->

   
</body>
</html>