<?php
session_start();
include 'Includes/dbconn.php';
$User_ID=$_SESSION['U_ID'];
$P_ID=$_SESSION["Product_ID"];
$P_Name=$_SESSION["Product_Name"];
$P_Price=$_SESSION["Product_Price"];

//Calculation For CGST AND SGST
$GST_RATE=6;
$QUANTITY=1;
$PRICE=$QUANTITY*$P_Price;
$CGST=($PRICE*6)/100;
$SGST=($PRICE*6)/100;
$TOTAL=$PRICE+$CGST+$SGST;


//Getting User Details
$SQL="SELECT * FROM tb_usertable WHERE U_ID={$User_ID} ";
$result=mysqli_query($conn,$SQL);
$row=mysqli_fetch_assoc($result);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="CSS/all.css">
    <script src="CSS/all.min.js"></script>
    
     <!-- JavaScript -->
     <script src="JS/jquery.min.js"></script>
     <script src="JS/popper.min.js"></script>
     <script src="JS/bootstrap.min.js"></script>
     <script src="JS/e902bcc639.js" crossorigin="anonymous"></script>
   
    
     <!-- Custom CSS -->
    <link rel="stylesheet" href="CSS/custom.css">
</head>
<body>

    <div class="container"  id="tblCustomers">
        <h1 class="card-title bg-success p-2">Code Solution</h1>
    <table class="table .table-stripped table-hover mt-4 ">
     <tr>
      <th class="text-center">Name:</th>
      <td><?php echo $row["U_name"]; ?></td>
      <th class="text-center">Date:</th>
      <td><?php echo date("d/y/Y"); ?></td>
      </tr>
      <tr>
      <th class="text-center">Email:</th>
      <td><?php echo $row["U_Email"]; ?></td>
      <th class="text-center">Time:</th>
      <td><?php echo date("h:/i/sa"); ?></td>
      </tr>
      <tr>
      <th class="text-center">Mobile:</th>
      <td><?php echo $row["U_Contact"]; ?></td>
      </tr>
     <tr>
         <th class="border p-2 bg-warning">Id</th>
         <th class="border p-2 bg-warning">Product name</th>
         <th class="border p-2 bg-warning">Quantity</th>
         <th class="border p-2 bg-warning">Price</th>
         <th class="border p-2 bg-warning">CGST</th>
         <th class="border p-2 bg-warning">SGST</th>
         <th class="border p-2 bg-warning">Total</th>
     </tr>
     <tr>
         <td><?php echo $P_ID; ?></td>
         <td><?php echo $P_Name; ?></td>
         <td><?php echo $QUANTITY; ?></td>
         <td><?php echo $PRICE; ?> Rs.</td>
         <td><?php echo $CGST; ?> Rs.</td>
         <td><?php echo $SGST; ?> Rs.</td>
         <td><?php echo $TOTAL; ?> Rs.</td>
     </tr>
    <tr>
        <th class="border p-2 bg-warning"></th>
        <th class="border p-2 bg-warning"></th>
        <th class="border p-2 bg-warning"></th>
        <th class="border p-2 bg-warning"></th>
        <th class="border p-2 bg-warning"></th>
        <th class="border p-2 bg-warning">Grand Total</th>
        <th class="border p-2 bg-warning"><?php echo $TOTAL; ?> Rs.</th>
    </tr>
    </table>
   
</div>
<div class="container">
<input type="button" class="btn btn-primary" id="btnExport" value="Export" onclick="Export()" />
</div>

<script type="text/javascript" src="JS/pdfmake.min.js"></script>
<script type="text/javascript" src="JS/html2canvas.min.js"></script>
<script type="text/javascript">
    function Export() {
        html2canvas(document.getElementById('tblCustomers'), {
            onrendered: function (canvas) {
                var data = canvas.toDataURL();
                var docDefinition = {
                    content: [{
                        image: data,
                        width: 500
                    }]
                };
                pdfMake.createPdf(docDefinition).download("Table.pdf");
            }
        });
    }
</script>
</body>
</html>