
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Manager</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="CSS/all.css">
    <script src="CSS/all.min.js"></script>
    
     <!-- JavaScript -->
     <script src="JS/jquery.min.js"></script>
     <script src="JS/popper.min.js"></script>
     <script src="JS/bootstrap.min.js"></script>
     <script src="JS/jquery-1.12.4.min.js"></script>
    
     <!-- Custom CSS -->
    <link rel="stylesheet" href="CSS/custom.css">
    <script>
    $(document).ready(function(){
        $("button").click(function(){
            $("ol").append("<li>list item <a href='javascript:void(0);' class='remove'>&times;</a></li>"); 
        });
        $(document).on("click", "a.remove" , function() {
            $(this).parent().remove();
        });
    });
</script>
   
</head>
<body  onload="load()">

<div class="row container-fluid justify-content-center mt-2">
<div class="col-md-11 bg-light mt-2">
<table class="table" id="Mytable">
<form action="Index.php" class="" method="form">

<tr>
<th class="bg-waning card-title">Name</th>
<th class="bg-waning card-title">Gender</th>
<th class="bg-waning card-title">Age</th>
<th class="bg-waning card-title">Contact</th>
<th class="bg-waning card-title">Add</th>
</tr>
<tr>
<td><input type="text" class="form-control" id="Name" name="Username"></td>
<td>
<select name="Gender" id="Gender" class="form-control">
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Others">Others</option>
</select>
</td>
<td><input type="text" class="form-control" id="Age" name="Age"></td>
<td><input type="text" class="form-control" id="Contact" name="Contact"></td>
<td><input type="submit" class="form-control btn-primary "></td>
</tr>"
</table>
</div>
<div class="col-md-1 ml-5 bg-light mt-2">
<Button type="submit" class="form-control btn-primary " name="GetForm"><i class="fas fa-plus"></i></Button>
</div>
</div>
    
</body>
</html>