<?php
   $host="localhost";
   $user="root";
   $pass="";
   $db="Delete";
   //Creating dtadbase connation
   $conn=mysqli_connect($host,$user,$pass,$db);
?>