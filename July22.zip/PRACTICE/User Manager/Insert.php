<?php
function GetInsertForm()
{
 echo "<tr>
<td><input type=\"text\" class=\"form-control\" id=\"Username\" name=\"Username\"></td>
<td>
<select name=\"Gender\" id=\"Gender\" class=\"form-control\">
<option value=\"Male\">Male</option>
<option value=\"Female\">Female</option>
<option value=\"Others\">Others</option>
</select>
</td>
<td><input type=\"text\" class=\"form-control\" id=\"Age\" name=\"Age\"></td>
<td><input type=\"text\" class=\"form-control\" id=\"Contaact\" name=\"Contact\"></td>
<td><input type=\"submit\" class=\"form-control btn-primary \"></td>
</tr>";

}
?>