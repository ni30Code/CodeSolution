<?php
session_start();
if(isset($_SESSION["User_Registered"]))
{
   header('location:User/UserProfile.php');
}
 include('Includes/dbconn.php');

 if(isset($_REQUEST["Signup"]))//Check Form Submission
  {
      //If form Element is blank
        if(($_REQUEST['Name'] == "") || ($_REQUEST["Gender"] == "") || ($_REQUEST['DOB'] == "")||($_REQUEST['Email'] == "")||($_REQUEST['Contact'] == "")||($_REQUEST['Password'] == "")){
        $errMessage ='<div class="alert alert-warning mt-2" role="alert">All Fields are Required</div>';
        } 
        else{
        //Check Wheather Email is registered or not
        $q="SELECT * FROM `usertable` WHERE `U_Email`='".$_REQUEST['Email']."'";
        $sql=mysqli_query($conn,$q);
          if(mysqli_num_rows($sql)==1){
           $errMessage = '<div class="alert alert-warning mt-2" role="alert">Email ID Already Registered</div>';
           }
          else{
            //Insert data into database
           $uname=$_REQUEST['Name'];
           $ugender=$_REQUEST['Gender'];
           $uDOB=$_REQUEST['DOB'];
           $uEmail=$_REQUEST['Email'];
           $ucontact=$_REQUEST['Contact'];
           $upwd=$_REQUEST['Password'];
           $q="INSERT INTO `tb_usertable`( `U_name`, `U_Gender`, `U_DOB`, `U_Email`, `U_Contact`, `U_Password`) 
           VALUES ('$uname','$ugender','$uDOB','$uEmail','$ucontact','$upwd')";
            $sql=mysqli_query($conn,$q);
           if($sql==true){
            $errMessage='<div class="alert alert-success mt-2">Account Created Successfully</div>';
            $_SESSION["User_Registered"]=true;
            }
           else{
            $errMessage='<div class="alert alert-danger mt-2">Unable to create account</div>';
               }
         }
       }
  }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page:Code Solution</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="CSS/all.min.css">
     <!-- JavaScript -->
     <script src="JS/jquery.min.js"></script>
     <script src="JS/popper.min.js"></script>
     <script src="JS/bootstrap.min.js"></script>
</head>
<body>
<div class="Container">
 <h1 class="text-center">Register with us</h1>
 </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="cols-sm-8">
        <form action="Signup.php" class="shadow-lg p-4">
          <label for="Name" class="mt-2">Name</label>
            <input type="text" class="form-control" name="Name" id="Name">
          <label for="Gender" class="mt-2">Gender</label>
            <select name="Gender" id="Gender" class="form-control " id="Gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Others">Others</option>
            </select>
          <label for="DOB"  class=" mt-2">DOB</label>
            <input type="DATE" name="DOB" class="form-control" >
          <label for=""  class="mt-2">Email</label>
            <input type="Email" name="Email" class=" form-control " >
            <small class="form-text">We Will never share this Email</small>
          <label for=""  class="mt-2">Contact</label>
            <input type="text" name="Contact" placeholder="Contact" class="form-control" >
          <label for=""   class="mt-2">Password</label>
            <input type="Password" name="Password" placeholder="Password" class="form-control" >
            <input type="submit" value="Signup" name="Signup" class="form-control btn-danger  mt-4">
        </form>
        <?php if(isset($errMessage)) {echo $errMessage;} ?>
      </div>
      
    </div>
    <div class="text-center">
      <a href="index.php" class="btn btn-primary text-center mt-2">Back To Home</a>
      </div>
  </div>
  
</body>
</html>