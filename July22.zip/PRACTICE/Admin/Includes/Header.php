<nav class="navbar bg-success">
  <a href="" class="navbar-brand text-white"><h3>Code Solutions</h3></a>
  <a href="../Includes/Logout.php"><i class="fas fa-power-off"></i>Logout</a>
</nav>