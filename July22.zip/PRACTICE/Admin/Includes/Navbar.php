
<nav class="navbar container navbar-expand-md navbar-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav-content" aria-controls="nav-content"
    aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
<div class="collapse navbar-collapse flex-column" id="nav-content">
    
        <ul class="navbar-nav d-inline">
              <li class="nav-item">
                <a class="nav-link text-body" href=""><strong class="bg-dark container text-white"> Welcome <?php echo $_SESSION["name"]; ?></strong></a>
                </li>
               <li class="nav-item">
                   <a class="nav-link text-danger" href="Dashboard.php">DashBoard</a>
               </li>
               <li class="nav-item">
                   <a class="nav-link text-danger" href="InsertProduct.php">Product Manager</a>
               </li>
               <li class="nav-item">
                   <a class="nav-link text-danger" href="AddUser.php">User Manager</a>
               </li>
               <li class="nav-item">
                   <a class="nav-link text-danger" href="AddUser.php">Employee Manager</a>
               </li>
               <li class="nav-item ">
                   <a class="nav-link text-danger" href="AddUser.php">Sell Report</a>
               </li>
               <li class="nav-item ">
                   <a class="nav-link text-danger" href="AddUser.php">Order Request</a>
               </li>

        </ul>
</div>
</nav>