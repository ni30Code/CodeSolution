<?php


function GetProductsWithoutImage()
{
    include '../Includes/dbconn.php';
    $SQL="SELECT * FROM tb_product";
    $result=mysqli_query($conn,$SQL);
    while( $row=mysqli_fetch_assoc($result))
    {
        echo "<tr>
        <td>".$row["product_id"]."</td>
        <td>".$row["product_name"]."</td>
        <td>".$row["product_category"]."</td>
        <td>".$row["RAM"]."</td>
        <td>".$row["product_price"]."</td>
        </tr>";
    }
}
function GetProductsWithImage()
{
    include '../Includes/dbconn.php';
    $SQL="SELECT * FROM tb_product";
    $result=mysqli_query($conn,$SQL);
    while( $row=mysqli_fetch_assoc($result))
    {
        $temp=$row["product_pic"];
        echo "<tr>
        <td>".$row["product_id"]."</td>
        <td>".$row["product_name"]."</td>
        <td>".$row["product_category"]."</td>
        <td>".$row["RAM"]."</td>
        <td>".$row["product_price"]."</td>
        <td>".$row["product_description"]."</td>
        <td><img src=\"$temp\" ></td>
        </tr>";
    }
}
?>