<?php
  session_start();
   include('../Includes/dbconn.php');
   include('../Includes/Product_Function.php');  

   //Check if form is submitted
   if(isset($_REQUEST["Add"])){
      $tmpfile=$_FILES["Product_Pic"] ["tmp_name"];
      $fileDest="Upload/".$_FILES["Product_Pic"] ["name"];
      move_uploaded_file( $tmpfile,$fileDest);
       $category=$_REQUEST["Product_Category"];
       $name=$_REQUEST["Model_Name"];
       $RAM=$_REQUEST["RAM"];
       $price=$_REQUEST["Product_Price"];
       $pic=$_FILES["Product_Pic"];
       $desc=$_REQUEST["Description"];
       $result =Addproduct($category,$name,$RAM,$price,$fileDest,$desc);
       if($result==true)
       {
         $msg='<div class="alert alert-success mt-2" role="alert">Record inserted successfully</div>';
       }
      
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="../CSS/bootstrap.min.css">

<!-- Font Awesome CSS -->
<link rel="stylesheet" href="../CSS/all.css">
<script src="../CSS/all.min.js"></script>
 <!-- JavaScript -->
 <script src="../JS/jquery.min.js"></script>
 <script src="../JS/popper.min.js"></script>
 <script src="J../S/bootstrap.min.js"></script>

<!-- Custom CSS -->
<link rel="stylesheet" href="../CSS/custom.css">
</head>
<body>
<nav class="navbar navbar-expand  navbar-dark bg-success pl-5 top-fixed">
  <a href="" class="navbar-brand text-white"><h3>Code Solutions</h3></a>
  <div class="collapse navbar-collapse ml-5" id="Mymenu">
        <ul class="navbar-nav">
        <li class="nav-item">
          <a href="InsertProduct.php" class="nav-link text-white"><i class="fas fa-plus"></i></a>
       </li>
        <li class="nav-item">
          <a href="DeleteItem.php" class="nav-link text-white"><i class="fas fa-trash"></i></a>
        </li>
        <li class="nav-item">
          <a href="UpdateItem.php" class="nav-link text-white"><i class="fas fa-edit"></i></a>
       </li>
        <li class="nav-item">
        <a href="ItemViewer.php" class="nav-link text-white"><i class="fas fa-eye"></i></a>
        </li>
        <li class="nav-item">
        <a href="../Includes/Logout.php" class="nav-link text-white"><i class="fas fa-power-off"></i>Logout</a>
        </li>
     </ul>
</nav>
<div class="row container">
  <div class="col-md-3 cols-sm-4 mt-2 text-center bg-light"> <!-- First Column Start Here-->
  <?php include 'Includes/Navbar.php'; ?>
  </div><!-- First Column End Here-->

<div class="col-md-9 cols-sm-8 mt-2 "><!-- Second Column Start Here-->

<form action="InsertProduct.php" method="post" enctype="multipart/form-data" class="shadow-lg p-4 form-group">
      <h1 class="text-center">Product Addition Form</h1>
      <div class="row m-2">
       <div class="cols-md-6"><!--Colum1 start Here-->
           <label for="P_Category" class="mt-2">Product_Category</label>
             <select name="Product_Category" id="P_Category" class="form-control">
              <option value="Mobiles">Mobiles</option>
              <option value="Laptop">Laptop</option>
              <option value="Camera">Camera</option>
             </select>
           <label for="RAM" class="mt-2">RAM CAtegory</label>
             <select name="RAM" id="RAM" class="form-control">
               <option value="4GB">4GB</option>
               <option value="8GB">8GB</option>
               <option value="16GB">16GB</option>
             </select>
           <label for="Product_Pic"  class="mt-2">Product Picture</label>
              <input type="file" name="Product_Pic" id="Product_Price" class="form-control">
        </div><!--Colum1 End Here-->

      <div class="col-md-6"><!--Colum2start Here-->
          <label for="Model_Name"  class="mt-2">Model Name</label>
              <input type="text" name="Model_Name" id="Model_Name" class="form-control">
          <label for="Product_Price"  class="mt-2">Product Price</label>
              <input type="text" name="Product_Price" id="Product_Price" class="form-control">
          
        </div><!--Colum2 End Here-->
        <label for="Description"  class=" form-group mt-2">Description</label>
            <textarea name="Description" id="Description" cols="30" rows="10" class="form-control">
            </textarea>
          <input type="submit" name="Add" class="btn btn-primary mt-2">
       
       </div><!--Row End Here-->
        
        <?php if(isset($msg)){ echo $msg;} ?>
    </div><!--Container End Here-->
   
   


  </div><!-- Second Column End Here-->
</div>
</body>
</html>