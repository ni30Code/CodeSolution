<?php
include 'Includes/Admin_Function.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.css">
    <script src="../CSS/all.min.js"></script>
    
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>
     <script src="../JS/e902bcc639.js" crossorigin="anonymous"></script>
   
    
     <!-- Custom CSS -->
    <link rel="stylesheet" href="../CSS/custom.css">
    <style>
    img{
        width:30px;
        height:60px;
    }
    </style>
    
</head>
<body>
<div class="containers">

<div class="row justify-content-center">
  
  <div class="col-md-6">
  <table class="table">
  <tr>
  <th>ID</th>
  <th>Name</th>
  <th>Category</th>
  <th>RAM</th>
  <th>Price</th>
  <th>Description</th>
  <th>Picture</th>
  </tr>
  <?php GetProductsWithImage(); ?>
  </table>
  </div>
</div>
</div>

    
</body>
</html>