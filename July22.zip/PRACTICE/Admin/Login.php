<?php
 session_start();
  //Redirect to Admin Panel When Admin is already logged in
  if(isset($_SESSION["is_AdminLogin"])){
   header('location:Dashboard.php');
   }

  include('../Includes/dbconn.php');
   if(!isset($_SESSION['is_AdminLogin'])){
      if(isset($_REQUEST['AdminName'])){
         //Filter Form Data
         $name = mysqli_real_escape_string($conn, trim($_REQUEST['AdminName']));
         $Password = mysqli_real_escape_string($conn, trim($_REQUEST['AdminPassword']));
         //SQL Query 
         $sql = "SELECT * FROM `tb_admin` WHERE `name`= '$name' AND `password` = '$Password' limit 1";
         $result = $conn->query($sql);
         if($result->num_rows == 1){
            //Create Session Variable
            $_SESSION['is_AdminLogin'] = true;
            $_SESSION['name'] = $name;
            echo "<script> location.href='Dashboard.php';</script>";
          exit; } 
          else {
     $errMessage = '<div class="alert alert-warning mt-2">Enter Valid Username and Password</div>';
    }
   }
  } else {
   echo "<script> location.href='Dashboard.php';</script>";
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login:Code Solutions</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="../CSS/all.min.css">
     <!-- JavaScript -->
     <script src="../JS/jquery.min.js"></script>
     <script src="../JS/popper.min.js"></script>
     <script src="../JS/bootstrap.min.js"></script>

    <!-- Google Font -->
 <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
     <link rel="stylesheet" href="CSS/custom.css">
   
</head>
<body>
<div class="container-fluid">
  <h1 class="text-center">Admin Login</h1>
  <div class="row justify-content-center">
  <div class="col-sm-4">
  <form action="Login.php"  class="shadow-lg p-4"  method="post">
     <label for="AdminName" class="font-weight-bold pl-2 mt-3">Email</label>
     <input type="text" name="AdminName" id="AdminName" class="form-control">
     <small class="form-text">We Will never share this Email</small>
     <label for="AdminPassword" class="font-weight-bold pl-2 mt-3">Password</label>
     <input type="Password" name="AdminPassword" id="AdminPassword" class="form-control">
     <input type="submit" name="Login" value="Login" class="form-control btn-success mt-3">
</form>
   <?php if(isset($errMessage)) {echo $errMessage;} ?>
<div class="text-center">
<a href="../index.php" class="btn btn-primary text-center mt-2">Back To Home</a>
</div>

</div>
</div>


</body>
</html>