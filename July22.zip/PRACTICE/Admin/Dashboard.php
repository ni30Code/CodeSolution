<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="../CSS/bootstrap.min.css">

<!-- Font Awesome CSS -->
<link rel="stylesheet" href="../CSS/all.css">
<script src="../CSS/all.min.js"></script>
 <!-- JavaScript -->
 <script src="../JS/jquery.min.js"></script>
 <script src="../JS/popper.min.js"></script>
 <script src="../JS/bootstrap.min.js"></script>

<!-- Custom CSS -->
<link rel="stylesheet" href="../CSS/custom.css">
</head>
<body>
<?php include 'Includes/Header.php'; ?>
<div class="row container justify-content-center">
  <div class="col-md-3 cols-sm-4 mt-2 text-center bg-light"> <!-- First Column Start Here-->
  <?php include 'Includes/Navbar.php'; ?>
  </div><!-- First Column End Here-->

  <div class="col-md-3 cols-sm-8 mt-2 "><!-- Second Column Start Here-->
        <div class="card shadow text-center bg-danger">
            <div class="card-title">
            <a href="ProductList.php" class="nav-link my-2-0 py-0"><h3 class="text-white">All Products</h3></a><hr class="bg-success">
            </div>
            <div class="card-body">
            <a class="btn btn-primary" data-toggle="collapse" href="#ProductList" role="button" aria-expanded="false" aria-controls="ProductList">
             Show
            </a>
            </div>
        </div>
  </div><!-- Second Column End Here-->

  <div class="col-md-3 cols-sm-8 mt-2 "><!-- Third Column Start Here-->
          <div class="card shadow text-center bg-warning">
             <div class="card-title">
             <a href="UserList.php" class="nav-link my-0 py-0"><h3 class="text-white">All Client-User</h3></a><hr class="bg-success">
             </div>
             <div class="card-body">
             <a class="btn btn-primary" data-toggle="collapse" href="#UserList" role="button" aria-expanded="false" aria-controls="UserList">
             Show
            </a>
             </div>
          </div>
  </div><!-- Third Column End Here-->

 <div class=" col-md-3 cols-sm-8 mt-2"> <!-- Fourth Column Start Here-->
          
         </div><!-- Fourth Column End Here-->
  </div><!--Row End Here-->  
<div class="row text-center">
<hr>

<div id="ProductList" class="collapse col-md-6 cols-sm-8 justify-content-center ">
<table class="table table-hover shadow">
  <tr>
    <th colspan="5">
    <h3 class="title bg-dark text-white text-center">List Of All Products</h3>
    </th>
   </tr>
   <tr>
  <th>Prod. ID</th>
  <th>Name</th>
  <th>Category</th>
  <th>RAM</th>
  <th>Price</th>
  </tr>
  <?php include 'Includes/Admin_Function.php'; GetProductsWithoutImage(); ?>
  </table>
</div>




<div id="UserList" class="collapse col-md-6 col-sm-8 ">
    <table class="table table-hover shadow">
    <tr>
    <th colspan="5">
    <h3 class="title bg-dark text-white text-center">List Of All  Users</h3>
    </th>
   </tr>
     <tr>
     <th>ID</th>
     <th>Name</th>
     <th>Email</th>
     <th>Contact</th>
     </tr>
    <?php function GetUsers()
  {
    include '../Includes/dbconn.php';
    $SQL="SELECT * FROM tb_usertable";
    $result=mysqli_query($conn,$SQL);
    while( $row=mysqli_fetch_assoc($result))
    {
        echo "<tr>
        <td>".$row["U_ID"]."</td>
        <td>".$row["U_name"]."</td>
        <td>".$row["U_Email"]."</td>
        <td>".$row["U_Contact"]."</td>
        </tr>";
    }
 }   
   GetUsers(); ?>
    </table>
  </div>

</div>
  
  

</body>
</html>
