<?php
session_start();
//Including Database Connection
 include '../Includes/dbconn.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="../CSS/bootstrap.min.css">

<!-- Font Awesome CSS -->
<link rel="stylesheet" href="../CSS/all.css">
<script src="../CSS/all.min.js"></script>
 <!-- JavaScript -->
 <script src="../JS/jquery.min.js"></script>
 <script src="../JS/popper.min.js"></script>
 <script src="../JS/bootstrap.min.js"></script>

<!-- Custom CSS -->
<link rel="stylesheet" href="../CSS/custom.css">
</head>
<body>
<nav class="navbar navbar-expand  navbar-dark bg-success pl-5 top-fixed">
  <a href="" class="navbar-brand text-white"><h3>Code Solutions</h3></a>
  <div class="collapse navbar-collapse ml-5" id="Mymenu">
        <ul class="navbar-nav">
        <li class="nav-item">
          <a href="InsertProduct.php" class="nav-link text-white"><i class="fas fa-plus"></i></a>
       </li>
        <li class="nav-item">
          <a href="DeleteItem.php" class="nav-link text-white"><i class="fas fa-trash"></i></a>
        </li>
        <li class="nav-item">
          <a href="UpdateItem.php" class="nav-link text-white"><i class="fas fa-edit"></i></a>
       </li>
        <li class="nav-item">
        <a href="ItemViewer.php" class="nav-link text-white"><i class="fas fa-eye"></i></a>
        </li>
        <li class="nav-item">
        <a href="../Includes/Logout.php" class="nav-link text-white"><i class="fas fa-power-off"></i>Logout</a>
        </li>
     </ul>
</nav>

<div class="row container">
  <div class="col-md-3 cols-sm-4 mt-2 text-center bg-light"> <!-- First Column Start Here-->
  <?php include 'Includes/Navbar.php'; ?>
  </div><!-- First Column End Here-->

<div class="col-md-9 cols-sm-8 mt-2 "><!-- Second Column Start Here-->
<table class="table table-hover shadow">
  <tr>
    <th colspan="5">
    <h3 class="title bg-dark text-white text-center">List Of All Products</h3>
    </th>
   </tr>
   <tr>
  <th>Prod. ID</th>
  <th>Name</th>
  <th>Category</th>
  <th>RAM</th>
  <th>Price</th>
  <th>Description</th>
  <th>Image</th>
  </tr>
  <?php include 'Includes/Admin_Function.php'; GetProductsWithImage(); ?>
  </table>
</div>

  </div><!-- Second Column End Here-->


 


      </div>
      </body>
      </html>